from Crypto.Util.number import getPrime, inverse, bytes_to_long, long_to_bytes

e = 3

p = getPrime(1024)
q = getPrime(1024)
phi = (p - 1) * (q - 1)
d = inverse(e, phi)

n = p * q

flag = b"CyberClass{N0t_th4t_ez_guys}"
pt = bytes_to_long(flag)
ct = pow(pt, e, n)

print(f"n = {n}")
print(f"e = {e}")
print(f"ct = {ct}")

pt = pow(ct, d, n)
decrypted = long_to_bytes(pt)
assert decrypted == flag